import torch
from torch import nn
from torch.utils.data import DataLoader
from torchvision.datasets import MNIST
from torchvision import transforms
from torchvision.utils import save_image
from matplotlib import pyplot as plt
import matplotlib.image as mpimg
# 定义VAE模型结构
class VAE(nn.Module):
    def __init__(self):
        super(VAE, self).__init__()
        # 编码器和解码器的具体结构可以根据需要设计
        # 这里仅作为示例，使用简单的网络结构
        self.encoder = nn.Sequential(
            nn.Linear(784, 300),
            nn.ReLU(),
            nn.Linear(300, 20),  # 二维的均值和标准差
        )
        self.decoder = nn.Sequential(
            nn.Linear(20, 300),
            nn.ReLU(),
            nn.Linear(300, 784),
            nn.Sigmoid(),  # 使用sigmoid将输出映射到0-1之间
        )

    def encode(self, x):
        h1 = self.encoder(x)
        return h1

    def decode(self, z):
        h2 = self.decoder(z)
        return h2

    def forward(self, x):
        enc_h = self.encoder(x)
        dec_h = self.decoder(enc_h)
        return dec_h, enc_h


# 准备数据集
transform = transforms.Compose([
    transforms.ToTensor(),
    #transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),  # 归一化数据
])
dataset = MNIST("F:/face", download=True, train=True, transform=transform)
dataloader = DataLoader(dataset, batch_size=64, shuffle=True)

# 实例化VAE模型
vae = VAE()
optimizer = torch.optim.Adam(vae.parameters(), lr=1e-3)
#if torch.cuda.is_available():
#   vae = vae.cuda()  # 将模型转移到CUDA
# 训练过程
for epoch in range(500):
    for batch_idx, (x, _) in enumerate(dataloader):
        x = x.view(-1, 784)#.cuda()   # 假设输入图像大小为32x32

        optimizer.zero_grad()
        dec_h, enc_h = vae(x)
        # 计算重建损失和KL散度
        rec_loss = nn.functional.binary_cross_entropy(dec_h, x, reduction='sum')
        kl_loss = -0.5 * torch.sum(1 + enc_h[0] - enc_h[1].pow(2) - enc_h[1].exp())
        loss = rec_loss + kl_loss
        loss.backward()
        optimizer.step()

        if batch_idx % 100 == 0:
            print(f"Epoch: {epoch}, Batch: {batch_idx}, Loss: {loss.item()}")

# 测试和可视化
with torch.no_grad():
    z = torch.randn(300, 20)
    generated_images = vae.decode(z).view(-1, 1, 28, 28)
    save_image(generated_images, "generated_images.png")